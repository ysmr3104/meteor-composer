//============================================================================
// classifier.js - Scoring candidates as more or less likely to be meteors
//
// Pure JavaScript, no PJSR dependency.
//
// This does NOT decide anything on its own. docs/requirements.md 6.2 settles
// the policy: a human screens everything afterwards, so losing one meteor
// costs more than letting thirty aircraft through. The score exists to put
// the likely ones first and to let an operator who wants a shorter list draw
// a line themselves. Nothing is discarded by default.
//
// The three signals it combines were each measured on the 2026-08-12 session
// before being written here (docs/requirements.md 6.1.0 and 4.6):
//
//   stationary   a track whose centroid does not move at all in registered
//                coordinates is a fixed structure - a star chain, a
//                diffraction spike - not a transient. One such position
//                accounted for 22 of the 411 candidates, all judged
//                not-a-meteor.
//   persistent   a track that moves smoothly across more than a meteor can
//                last is a satellite or an aircraft. The boundary is two
//                frames, not one: a meteor at an exposure boundary is
//                recorded in both.
//   colour       the green fraction of the trail's own light. Measured
//                balanced accuracy 0.801 on its own, better than elongation
//                at 0.540 - but sensitivity only 0.710, so it must never be
//                used as a filter.
//
// Colour is scored by RANK within the session, never against an absolute
// threshold. The not-a-meteor population sat at 0.458 rather than the
// colourless 0.333, which is a property of the camera (a Bayer array has
// twice as many green photosites), so an absolute cut would not survive a
// change of equipment.
//============================================================================

var DEFAULT_SCORE_OPTIONS = {
   // Longest track that could still be a single meteor. See
   // candidate_ops.DEFAULT_MATCH_OPTIONS.maxMeteorFrames for why it is 2.
   maxMeteorFrames: 2,

   // A recurring detection counts as a fixed structure when every occurrence
   // sits within this radius of the group's centre, in samples of the working
   // field. The measured spread of the real example was under 0.1 samples, so
   // this is loose by a wide margin.
   fixedRadius: 3.0,

   // ...and when their lengths agree to within this fraction. The real fixed
   // structure varied by 0.4%; a coincidental cluster of unrelated candidates
   // in the same place varied by 44%. The gap is wide enough that the exact
   // value hardly matters.
   fixedLengthTolerance: 0.15,

   // How many occurrences before a position counts as a fixed structure.
   //
   // Must be above 2 so that a meteor straddling an exposure boundary - which
   // appears twice in nearly the same place - can never qualify. Three would
   // do, but a cluster of exactly three containing a real meteor was measured,
   // so four leaves margin. The real structure appeared 22 times.
   fixedMinOccurrences: 4,

   // Kept for analyzeTracks, which still describes how far a track wanders.
   stationaryRadius: 3.0,
   stationaryMinFrames: 3,

   // Multipliers, not vetoes. Even a stationary candidate keeps a non-zero
   // score so that sorting by score never hides it completely.
   stationaryFactor: 0.02,

   // A candidate that runs along the edge of the frame's data is that edge.
   //
   // Registration leaves regions with nothing in them - a strip down one side of
   // every frame, and on some frames a wedge covering nearly 40% - and their
   // boundary is a genuinely straight, high-contrast line. Sixty-one of 411
   // candidates on the evaluation night sat within five samples of one.
   //
   // Scored down rather than rejected, and NOT by asking whether the candidate
   // is near an edge. A visual meteor of that night comes within 4 px of the
   // border and two more meteors do as well: "near an edge" would take the
   // recall gate with it. What separates them is whether the candidate lies
   // ALONG the boundary, which was measured at 49% to 100% for the artefacts
   // against 0% to 5% for the meteors.
   edgeContactThreshold: 0.30,
   edgeContactFactor: 0.02,
   persistentFactor: 0.15,

   // How much of the score colour is allowed to move. At 0.7 a candidate in
   // the greenest part of the session scores about three times one in the
   // least green part, which is in line with a feature whose measured
   // accuracy is 0.8 - strong, but not strong enough to decide alone.
   colourWeight: 0.7
};

// --- Fixed structures -------------------------------------------------------

// Find detections that keep coming back in the same place with the same
// shape, anywhere in the session.
//
// This deliberately does NOT go through the cross-frame track linker.
// matchAcrossFrames only joins candidates in frames at most maxFrameGap
// apart, because it exists to follow something moving. A fixed structure is
// not moving and does not appear on a schedule: the real example turned up in
// 22 frames spread over 613, so the linker split it into fragments and only 8
// of the 22 were ever recognised.
//
// Position alone is not safe. A cluster of three candidates within 3 samples
// of each other was measured that contained a real meteor - things do
// coincide. What separates the fixed structure is that it is the SAME
// detection every time:
//
//   fixed structure at (421.8, 181.2)   length 14.07 to 14.13   spread 0.4%
//   the coincidental cluster            length 13.4, 20.1, 21.4  spread 44%
//
// So shape has to agree too, and the margin between the two cases is wide.
function findFixedStructures(rows, options) {
   var opt = mergeClassifierOptions(options);
   var n = rows.length;
   var parent = [];
   var i, j;
   for (i = 0; i < n; ++i) {
      parent.push(i);
   }

   function find(a) {
      while (parent[a] !== a) {
         parent[a] = parent[parent[a]];
         a = parent[a];
      }
      return a;
   }
   function union(a, b) {
      var ra = find(a), rb = find(b);
      if (ra !== rb) {
         parent[rb] = ra;
      }
   }

   // O(n^2). At 411 candidates that is trivial; a night that produced tens of
   // thousands would want a spatial index, but nothing near that has been
   // seen and an index would be untested complexity.
   for (i = 0; i < n; ++i) {
      var a = rows[i].candidate;
      for (j = i + 1; j < n; ++j) {
         var b = rows[j].candidate;
         var dx = a.cx - b.cx;
         var dy = a.cy - b.cy;
         if (dx * dx + dy * dy > opt.fixedRadius * opt.fixedRadius) {
            continue;
         }
         if (!similarLength(a.length, b.length, opt.fixedLengthTolerance)) {
            continue;
         }
         union(i, j);
      }
   }

   var groups = {};
   for (i = 0; i < n; ++i) {
      var root = find(i);
      if (groups[root] === undefined) {
         groups[root] = [];
      }
      groups[root].push(i);
   }

   var found = [];
   for (var key in groups) {
      var members = groups[key];
      if (members.length < opt.fixedMinOccurrences) {
         continue;
      }
      // Union-find joins transitively, so a chain of near-misses could form a
      // group that is not tight as a whole. Check the finished group rather
      // than trusting the pairwise steps that built it.
      var stats = groupStats(rows, members);
      if (stats.positionSpread > opt.fixedRadius) {
         continue;
      }
      if (stats.lengthSpread > opt.fixedLengthTolerance) {
         continue;
      }
      found.push({
         members: members,
         count: members.length,
         cx: stats.cx,
         cy: stats.cy,
         positionSpread: stats.positionSpread,
         lengthSpread: stats.lengthSpread
      });
   }
   found.sort(function (p, q) { return q.count - p.count; });
   return found;
}

function similarLength(a, b, tolerance) {
   var mean = (a + b) / 2;
   if (mean <= 0) {
      return a === b;
   }
   return Math.abs(a - b) / mean <= tolerance;
}

function groupStats(rows, members) {
   var sumX = 0, sumY = 0, i;
   var minLen = Infinity, maxLen = -Infinity;
   for (i = 0; i < members.length; ++i) {
      var c = rows[members[i]].candidate;
      sumX += c.cx;
      sumY += c.cy;
      if (c.length < minLen) {
         minLen = c.length;
      }
      if (c.length > maxLen) {
         maxLen = c.length;
      }
   }
   var cx = sumX / members.length;
   var cy = sumY / members.length;

   var spread = 0;
   for (i = 0; i < members.length; ++i) {
      var d = rows[members[i]].candidate;
      var dist = Math.sqrt((d.cx - cx) * (d.cx - cx) + (d.cy - cy) * (d.cy - cy));
      if (dist > spread) {
         spread = dist;
      }
   }
   var meanLen = (minLen + maxLen) / 2;
   return {
      cx: cx, cy: cy,
      positionSpread: spread,
      lengthSpread: meanLen > 0 ? (maxLen - minLen) / meanLen : 0
   };
}

// Mark every row that belongs to a fixed structure. Returns the structures.
function markFixedStructures(rows, options) {
   var found = findFixedStructures(rows, options);
   var i, j;
   for (i = 0; i < rows.length; ++i) {
      rows[i].stationary = false;
      rows[i].fixedCount = 0;
   }
   for (i = 0; i < found.length; ++i) {
      for (j = 0; j < found[i].members.length; ++j) {
         var row = rows[found[i].members[j]];
         row.stationary = true;
         row.fixedCount = found[i].count;
      }
   }
   return found;
}

// --- Track geometry ---------------------------------------------------------

// Summarise each track: how far it wanders, and what that implies.
//
// `tracks` is the output of candidate_ops.matchAcrossFrames.
function analyzeTracks(tracks, options) {
   var opt = mergeClassifierOptions(options);
   var out = [];
   for (var i = 0; i < tracks.length; ++i) {
      var track = tracks[i];
      var members = track.members;

      var sumX = 0, sumY = 0;
      var j;
      for (j = 0; j < members.length; ++j) {
         sumX += members[j].candidate.cx;
         sumY += members[j].candidate.cy;
      }
      var meanX = sumX / members.length;
      var meanY = sumY / members.length;

      var spread = 0;
      for (j = 0; j < members.length; ++j) {
         var dx = members[j].candidate.cx - meanX;
         var dy = members[j].candidate.cy - meanY;
         var d = Math.sqrt(dx * dx + dy * dy);
         if (d > spread) {
            spread = d;
         }
      }

      // Kept as a description of the track's own geometry. It is NOT what
      // decides a fixed structure: findFixedStructures() does that, because
      // a fixed structure does not respect the linker's frame-gap limit and
      // the linker only ever saw 8 of the real one's 22 occurrences.
      var stationary = members.length >= opt.stationaryMinFrames
                    && spread <= opt.stationaryRadius;

      out.push({
         id: track.id,
         length: members.length,
         meanX: meanX,
         meanY: meanY,
         spread: spread,
         stationary: stationary,
         // A fixed structure is not a satellite. Reporting it as `persistent`
         // as well would be filtering it for the wrong reason, and the reason
         // is what the operator reads.
         persistent: !stationary && members.length > opt.maxMeteorFrames
      });
   }
   return out;
}

// --- Colour ranking ---------------------------------------------------------

// Green fraction of a candidate's own light, background already removed.
//
// Returns null when the measurement is unusable: on a faint trail the
// background-subtracted total can come out at or below zero, and a ratio
// against that is meaningless rather than merely noisy.
function greenFraction(colour) {
   if (!colour) {
      return null;
   }
   var total = colour.r + colour.g + colour.b;
   if (!(total > 0)) {
      return null;
   }
   return colour.g / total;
}

// Rank of `value` within `sorted`, as a fraction from 0 to 1.
//
// Ranking rather than an absolute threshold is deliberate: what counts as
// "green" depends on the camera, so the only stable comparison is against the
// rest of the same session.
function rankOf(value, sorted) {
   if (sorted.length === 0) {
      return 0.5;
   }
   var lo = 0, hi = sorted.length;
   while (lo < hi) {
      var mid = (lo + hi) >> 1;
      if (sorted[mid] < value) {
         lo = mid + 1;
      } else {
         hi = mid;
      }
   }
   // Count how many are strictly below, plus half of the ties, so identical
   // values all get the same rank instead of depending on array order.
   var below = lo;
   var equal = 0;
   while (lo + equal < sorted.length && sorted[lo + equal] === value) {
      ++equal;
   }
   return (below + equal / 2) / sorted.length;
}

// Sorted green fractions across the session, for ranking against.
function colourPopulation(rows) {
   var values = [];
   for (var i = 0; i < rows.length; ++i) {
      var g = greenFraction(rows[i].colour);
      if (g !== null) {
         values.push(g);
      }
   }
   values.sort(function (a, b) { return a - b; });
   return values;
}

// --- Scoring ----------------------------------------------------------------

// Score one candidate from 0 to 1. Higher means more likely to be a meteor.
//
// `row` carries { trackLength, stationary, persistent, colour }. `population`
// is colourPopulation(rows); pass null to score without colour, which is what
// happens before the colour pass has run.
//
// The reasons are part of the output, not a debugging aid. An operator being
// asked to trust an ordering deserves to see why something was pushed down,
// and "stationary across 22 frames" is a statement they can check.
function scoreCandidate(row, population, options) {
   var opt = mergeClassifierOptions(options);
   var score = 1.0;
   var reasons = [];

   if (row.stationary) {
      score *= opt.stationaryFactor;
      // Written for the operator, not for the implementation. "Fixed
      // structure" is what this is called in the code and in the design notes,
      // and asked what it meant, the operator said it was hard to tell. What
      // is actually known is the observation - it is at the same place every
      // time, so it cannot be something that flew past - and the cause is an
      // inference, offered as one.
      reasons.push("at the same place in " + row.trackLength
                   + " frames - it never moves, so nothing flew past here"
                   + " (a star, most likely)");
   } else if (row.persistent) {
      score *= opt.persistentFactor;
      reasons.push("moves across " + row.trackLength
                   + " frames - longer than a meteor can last");
   }

   var contact = row.candidate !== undefined && row.candidate !== null
      ? row.candidate.edgeContact : row.edgeContact;
   if (typeof contact === "number" && contact >= opt.edgeContactThreshold) {
      score *= opt.edgeContactFactor;
      reasons.push("runs along the edge of the frame's data for "
                   + (contact * 100).toFixed(0) + "% of its length"
                   + " - that edge is a straight line, and this is it");
   }

   var g = greenFraction(row.colour);
   if (g !== null && population !== null && population.length > 0) {
      var rank = rankOf(g, population);
      score *= (1 - opt.colourWeight) + opt.colourWeight * rank;
      reasons.push("green fraction " + g.toFixed(3)
                   + " ranks at " + (rank * 100).toFixed(0)
                   + "% of this session");
   }

   return { score: score, reasons: reasons };
}

// Score every row in place and return them. `rows` are session_model rows
// with `stationary` and `colour` already attached.
function scoreAll(rows, options) {
   var population = colourPopulation(rows);
   for (var i = 0; i < rows.length; ++i) {
      var result = scoreCandidate(rows[i], population, options);
      rows[i].score = result.score;
      rows[i].scoreReasons = result.reasons;
   }
   return rows;
}

// --- Presets ----------------------------------------------------------------

// requirements.md 6.2 asks for three presets plus one slider, rather than
// exposing every threshold by default.
//
// These are cutoffs on the score, and every one of them is a suggestion: the
// candidates below the line are still in the list, just sorted to the bottom.
// "loose" is 0 precisely so that the default hides nothing at all.
// Measured on the 2026-08-12 session (411 candidates, 31 labelled meteors,
// tests/eval/evaluate_classifier.js):
//
//   cutoff   meteors kept   rows remaining
//     0.00        31 / 31      411   everything
//     0.05        31 / 31      369
//     0.20        31 / 31      116
//     0.40        31 / 31      100
//     0.50        29 / 31       87   <- meteors start being lost
//
// The lowest-scoring meteor came out at 0.446. These cutoffs sit well below
// it on purpose: a threshold read off one night's data would be fitted to
// that night, and the cost of being wrong is asymmetric. `strict` at 0.20
// leaves better than a factor of two in hand, `standard` closer to nine.
var PRESETS = {
   loose:    { cutoff: 0.0,  label: "Loose - show everything" },
   standard: { cutoff: 0.05, label: "Standard - drop what never moves" },
   strict:   { cutoff: 0.20, label: "Strict - keep the likely meteors" }
};

function presetNames() {
   return ["loose", "standard", "strict"];
}

// --- Utility ----------------------------------------------------------------

function mergeClassifierOptions(options) {
   var out = {};
   for (var k in DEFAULT_SCORE_OPTIONS) {
      out[k] = DEFAULT_SCORE_OPTIONS[k];
   }
   if (options) {
      for (var j in options) {
         if (options[j] !== undefined) {
            out[j] = options[j];
         }
      }
   }
   return out;
}

// --- Exports ---------------------------------------------------------------

if (typeof module !== "undefined") {
   module.exports = {
      DEFAULT_SCORE_OPTIONS: DEFAULT_SCORE_OPTIONS,
      PRESETS: PRESETS,
      presetNames: presetNames,
      analyzeTracks: analyzeTracks,
      findFixedStructures: findFixedStructures,
      markFixedStructures: markFixedStructures,
      greenFraction: greenFraction,
      rankOf: rankOf,
      colourPopulation: colourPopulation,
      scoreCandidate: scoreCandidate,
      scoreAll: scoreAll
   };
}
